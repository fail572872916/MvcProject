package com.example.netease.market.common;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StyleRes;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.wnhzw.R;

import java.util.Random;

/**
 * Created by Administrator on 2018/8/29.
 */

public class Timer_Tip extends Dialog implements View.OnClickListener {
	public Timer_Tip(@NonNull Context context) {
		super(context);
		this.context = context;
	}

	Context context;

	public Timer_Tip(@NonNull Context context, @StyleRes int themeResId) {
		super(context, themeResId);
		this.context = context;
	}

	private void applyCompat() {


		getWindow().setGravity(Gravity.TOP);




        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

	protected Timer_Tip(@NonNull Context context, boolean cancelable,
                        @Nullable OnCancelListener cancelListener) {
		super(context, cancelable, cancelListener);
	}


	LinearLayout rl_rootview;
	CommCallBack callBack;


	// 设置回调
	public void setCallBack(CommCallBack callBack) {
		this.callBack = callBack;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

	setCanceledOnTouchOutside(false);
		setContentView(R.layout.header_toast);

		rl_rootview = (LinearLayout) findViewById(R.id.rl_rootview);


		applyCompat();

		rl_rootview.setOnClickListener(this);


		/** 倒计时60秒，一次1秒 */
		new CountDownTimer(20 * 1000, 1000) {
			@Override
			public void onTick(long millisUntilFinished) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onFinish() {
				// 计时结束关闭
				dismiss();
			}
		}.start();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {

		case R.id.rl_rootview:
			dismiss();
			break;
		}
	}

	public interface OnClickListener {
		/**
		 * 当点击某条的时候回调这方法
		 */
		public void onItemClick(Context context, boolean cancelorsure);
	} // 定义接口

	private OnClickListener onClickListener;

	/**
	 * 设置Item的点击监听
	 * 
	 * @param listener
	 */
	public void setOnClickListener(OnClickListener listener) {
		this.onClickListener = listener;
	}



}
